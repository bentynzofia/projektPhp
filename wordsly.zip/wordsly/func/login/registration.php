<?php
  if(isset($_POST['button'])) {
    header('Location: http://localhost/projektPhp/wordsly/user/login/signin.php');
  }


 ?>
