<?php
session_start();

header("location:  http://localhost/projektPhp/wordsly/user/login/login.php");
session_destroy();
 ?>
