<?php
session_start();
include("../inc/index.php");
 ?>
      <div class="studentInterface">

      </div>
      <div class="studentContain">
        <div class="buttons">


        <button type="button" name="button">
          <a href="#">add set</a>
        </button>
        <button type="button" name="button">
          <a href="#">set list</a>
        </button>
        <button type="button" name="button">
          <a href="#">lessons</a>
        </button>
        <button type="button" name="button">
          <a href="../../func/login/logout.php">log out</a>
        </button>

      </div>
      </div>

      <img src="../../img/notebook.svg" alt="">


    </div>
  </body>
</html>
