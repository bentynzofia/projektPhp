<?php
include("../inc/index.php");
 ?>
      <div class="studentInterface">

      </div>
      <div class="studentContain">
        <div class="buttons">

        <button type="button" name="button">
          <a href="#">classes</a>
        </button>
        <button type="button" name="button">
          <a href="#">stats</a>
        </button>
        <button type="button" name="button">
          <a href="#">ranking</a>
        </button>

      </div>
      </div>
  <img src="../../img/idea.svg" alt="">
    </div>
  </body>
</html>
