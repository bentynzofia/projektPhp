<?php
include('../inc/logisignin.php');
include('../../func/login/registration.php');
include('../../func/db/conn.php');

 ?>
 <form  method="post">
   <input type="text" name="login" value="" placeholder="username" autocomplete="off">
   <input type="password" name="password" value="" placeholder="password" autocomplete="off"></br>
   <input type="submit" class="button fillIn" name="loginButton" value="login">
   <p id="notice"class="space ">Not having an account already?</p>
   <input class="button space" type="submit" name="button" value="register">

 </form>


      </div>
      </div>

      <img src="../../img/8852.jpg" alt="">

    </div>

  </body>
</html>
