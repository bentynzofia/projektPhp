<?php
include("../inc/index.php");
 ?>
      <div class="studentInterface">

      </div>
      <div class="studentContain">
        <div class="buttons">

        <button type="button" name="button">
          <a href="#">teachers</a>
        </button>
        <button type="button" name="button">
          <a href="#">students</a>
        </button>
        <button type="button" name="button">
          <a href="#">classes</a>
        </button>

      </div>
      </div>
  <img src="../../img/settings (1).svg" alt="">
    </div>
  </body>
</html>
